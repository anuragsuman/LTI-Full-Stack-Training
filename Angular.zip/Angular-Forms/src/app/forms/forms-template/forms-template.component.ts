import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms-template',
  templateUrl: './forms-template.component.html',
  styleUrls: ['./forms-template.component.css']
})
export class FormsTemplateComponent implements OnInit {

  name : string;
  category : string;
  cost : number;

  constructor() { }
 
  saveProduct(frm : any){
    this.name = frm.pname;
    this.category = frm.pcat;
    this.cost = frm.pcost;
  }


  ngOnInit() {
  }

}
