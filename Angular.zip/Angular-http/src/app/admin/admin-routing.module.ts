import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


// way to navigate to a component using url
// Maps a URL with component : Route object
// an array (Collection) of Route Object
const routes: Routes = [];
/*const routes: Routes = [
  {
    path : "admin", 
    component : AdminComponent, 
    children[
      {path : "list", component : ListComponent}, // /admin/list
      {path : "report", component : ReportComponent}, // /admin/report
    ] }


];*/


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
