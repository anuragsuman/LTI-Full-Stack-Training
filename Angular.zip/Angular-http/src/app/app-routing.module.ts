import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './common/home/home.component';
import { AboutComponent } from './common/about/about.component';
import { ContactComponent } from './common/contact/contact.component';
import { PostComponent } from './postresources/post/post.component';
import { SearchComponent } from './common/search/search.component';
import { ErrorComponent } from './common/error/error.component';
import { LoginComponent } from './secure/login/login.component';
import { LogoutComponent } from './secure/logout/logout.component';
import { AuthGuardService } from './service/auth-guard.service';

// way to navigate to a component using url
// Maps a URL with component : Route object
// an array (Collection) of Route Object
const routes: Routes = [
  // route Object
  // defualt roo component : HOME
  {path : "", redirectTo: "home", pathMatch : "full"},
  {path:"home", component : HomeComponent},
  {path:"about-us", component : AboutComponent},
  {path:"contact-us", component : ContactComponent},
  {path : "login", component : LoginComponent},

  // secure mapping
  {path:"post", component : PostComponent, canActivate : [AuthGuardService]},
  {path : "logout", component : LogoutComponent, canActivate : [AuthGuardService]},
  

  // /:srch : Path Variable(Key)
  // {path:"search/:srch/:detail", component: SearchComponent}
  {path:"search/:srch", component: SearchComponent},

  // fallback mapping
  {path : "**", component : ErrorComponent}

 /* {
  path : "admin", 
  component : AdminComponent, 
  children[
    {path : "list", component : ListComponent}, // /admin/list
    {path : "report", component : ReportComponent}, // /admin/report
  ] }*/





];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
