import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Post } from 'src/app/model/post.model';
@Component({
  selector: 'app-post-entry',
  templateUrl: './post-entry.component.html',
  styleUrls: ['./post-entry.component.css']
})
export class PostEntryComponent implements OnInit {

  // custom event with feature that we can emit the data as well
  // need to make capable to emit data to another component
  @Output()
  newpost : EventEmitter<Post>;
  constructor() { 
    this.newpost = new EventEmitter();
  }

  addPost(txtTitle:HTMLInputElement, txtTags:HTMLInputElement, txtPost:HTMLInputElement){
    // create a new Post Object 
    let post = new Post(txtTitle.value, txtTags.value, txtPost.value);
    // push post object to parent component
    // emit the event programmatically (with data)
    this.newpost.emit(post);


    txtTitle.value = "";
    txtTags.value = "";
    txtPost.value = "";
}



  ngOnInit() {
  }

}
