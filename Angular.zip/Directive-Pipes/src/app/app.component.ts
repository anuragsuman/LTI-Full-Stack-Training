import { Component } from '@angular/core';

@Component({
  // custom tag of component
  selector: 'app-root',
  // template : `<h1>Hello from Component</h1>`,
  // view file
  templateUrl: './app.component.html',
  // array of multiple css files
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  show : boolean;
  a: number;
  b: number;
  sports : string;
  // myStyle : string;
  myStyle : Object;
  bgColor : string;
  classToApply : Object;

  email : string;


  constructor(){
    this.show = true;
    this.a = 10;
    this.b = 20;
    this.sports = "xyz";
    this.myStyle = {'background-color':'red'};
    this.bgColor = "red";
    this.classToApply = {
      borderedextra : true
      // style : boolean status (variable)
    };

    this.email = "first@mail.com";
  }

  getStatus():boolean{
    return this.show;
  }
  changeStatus(){
    this.show = !this.show;
  }
}
