import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomComponent } from './custom/custom.component';
import { PostComponent } from './postresources/post/post.component';
import { PostListComponent } from './postresources/post-list/post-list.component';
import { PostEntryComponent } from './postresources/post-entry/post-entry.component';

@NgModule({
  // array of all components inside the current module
  declarations: [
    AppComponent,
    CustomComponent,
    PostComponent,
    PostListComponent,
    PostEntryComponent
  ],
  // allows to integrate other modules with your
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  // inject specific dependency (for all child components)
  providers: [],
  // under the current module, which component(s) can be used as bootstrap
  bootstrap: [AppComponent]
})
export class AppModule { }
