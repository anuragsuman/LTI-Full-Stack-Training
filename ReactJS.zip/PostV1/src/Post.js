import React,{ Component } from "react";
import './css/Post.css';

class Post extends Component{
  
  render(){
    return(
      <div className="post">
          {/*this.props.postdata.title*/}
        <p><h4>Title : {this.props.title}</h4></p>
        <hr/>
        <p><i>Tags : {this.props.tags}</i></p>
        <p>{this.props.post}</p>
        {/*  Comments */}
      </div>
    );
  }
}

export default Post;