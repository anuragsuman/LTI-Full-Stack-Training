import React,{ Component } from "react";
import Post from "./Post";
import PostForm from "./PostForm";
import $ from 'jquery';

class PostBox extends Component{
  // method from Component to be overridden

  constructor(){
    super();
    // set the initial state
    // an object provided by Component class
    this.state = {
      show : true,
      posts : []
      /*posts : [
        {id : 1, title : "ReactJS", tags : "#frontend", post : "JS Library"},
        {id : 2, title : "Angular", tags : "#frontend", post : "JS Framework"},
        {id : 3, title : "Spring", tags : "#backend", post : "Java Framework"}
    ]*/
      // n number of fields
    }  
  }

  // exclusive method to read data from server
  _fetchFromServer(){
    // async call to server
    $.ajax(
      {
        method : "GET",
        url : "http://localhost:3000/post",
        success : (postsFromServer) => {this.setState({posts : postsFromServer})},
        error : () => {}
      }
    );
  }

  // before the first rendering 
  // life cycle hook method
  componentWillMount(){
    this._fetchFromServer();
  }

  // after first rendering: initiate the daemon process
  componentDidMount(){
    // setInterval(<method to call>, <interval>);
    this._timer = setInterval(()=>{this._fetchFromServer()}, 5000);
  }

  // stop pinging to server
  componentWillUnmount(){
    clearInterval(this._timer);
  }

  // exclusive method to manage all posts
  // 1. Hold the repo
  // 2. generate  JSX for it
  _getPosts(){
      // local method data
      /*const posts = [
          {id : 1, title : "ReactJS", tags : "#frontend", post : "JS Library"},
          {id : 2, title : "Angular", tags : "#frontend", post : "JS Framework"},
          {id : 3, title : "Spring", tags : "#backend", post : "Java Framework"}
      ];*/
      return this.state.posts.map((post) => {
          return (<Post id={post.id} title={post.title} tags={post.tags} post={post.post}/>);
          // return (<Post postdata={post}/>);  
      });
      
  }

  _handleClick(){
    // generate a call to render method
    // no direct call of render method
    // re-renderring is based on certain criteria
    // this.state.show = !this.state.show; (never recommended)
    this.setState({show : !this.state.show});
  }


  // will pass this method as prop to child component
  _addPost(new_title, new_tags, new_post){
    
    // create an object
    const newPost = {
      title : new_title,
      tags : new_tags,
      post : new_post
    };

    // call to server
    // $.post(<url>,<data>,<success>,<error>);
    $.post("http://localhost:3000/post",newPost, (server_post)=>{
      this.setState({posts : this.state.posts.concat([server_post])});
    })

    // add post to my collection
    // this.posts.concat([newPost]); // renderring will not take place
    // this.setState({posts : this.state.posts.concat([newPost])});
  }

  render(){
    
    // document.getElementById('');
    const postJSX = this._getPosts();
    let postData = <div>{postJSX}</div>
    if(!this.state.show)
      postData = "";
    // must return  UI as JSX
    return(
      <div>
        <h2>Posts...</h2>
        <h4>Posts : {postJSX.length}</h4>
        <PostForm addpost= {this._addPost.bind(this)}/>
        <button onClick={this._handleClick.bind(this)}>Show/Hide</button>
        {postData}

        {/* anything to be treated as JS must be written curly braces*/}
        {/*document.getElementById('')*/}
        {/* data required to be sent to another comp need to be passed as attribute */}
        {/* props */}
        {/*  
        <Post title="ReactJS" tags="#frontend" post="JS Library"/>
        <Post title="Angular" tags="#frontend" post="JS Framework"/>
        <Post title="Spring" tags="#backend" post="Java Framework"/>
        */}
      </div>
    );
  }
}

export default PostBox;