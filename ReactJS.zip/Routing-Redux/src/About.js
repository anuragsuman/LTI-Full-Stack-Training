import React,{ Component } from "react";

class About extends Component{
  // method from Component to be overridden
  render(){
    // must return  UI as JSX
    return(
      <div>
        <h1>This is About UsPage!</h1>
      </div>
    );
  }
}

export default About;
