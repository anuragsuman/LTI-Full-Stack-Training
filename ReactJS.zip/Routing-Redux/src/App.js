import React,{ Component } from "react";
import routing from "./routing";

class App extends Component{
  // method from Component to be overridden
  render(){
    // must return  UI as JSX
    return(
      <div>
        {routing}
      </div>
    );
  }
}

export default App;
