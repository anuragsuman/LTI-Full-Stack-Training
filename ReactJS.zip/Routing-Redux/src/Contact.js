import React,{ Component } from "react";

class Contact extends Component{
  // method from Component to be overridden
  render(){
    // must return  UI as JSX
    return(
      <div>
        <h1>This is Contact Us Page!</h1>
      </div>
    );
  }
}

export default Contact;
