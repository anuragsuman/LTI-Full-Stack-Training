import React,{ Component } from "react";
import { connect } from "react-redux";

class Counter extends Component{

   _increment(){
       // dispatch  : call the reducer and pass the wrapper object
    this.props.dispatch({type: "INCREMENT"});
   } 

   _decrement(){
    this.props.dispatch({type: "DECREMENT"});
   }

  render(){
    return(
      <div>
        <h1>Counter</h1>
        <div>
            <button onClick={this._increment.bind(this)}>INCREMENT</button>
            <br/>
                <span cssStyle="font-size : 30px">{this.props.count}</span>
            <br/>
            <button onClick={this._decrement.bind(this)}>DECREMENT</button>        
        </div>
      </div>
    );
  }
}

// configure the component to connect to store
// and specify what part of store to use
// mapper function
// Won't have access to store directly (logic of mapping)
function mapStoreToProp(store){
    // return an object
    // part of state which is required by current component
    return {
        // propname : state fld
        count : store.count
        // criticalData : store.f1
        // dispatch is auto mapped to props
    }
}

// connect will provide store object to mapper function
// return the mapped object, which is required to be made available to comp
// fn = connect(<mapper function>)
// fn : allows to pass prop to component
// updatedComponent = fn(<component>)
// export default updatedComponent

export default connect(mapStoreToProp)(Counter);
