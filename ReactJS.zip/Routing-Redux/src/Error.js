import React,{ Component } from "react";

class Error extends Component{
  // method from Component to be overridden
  render(){
    // must return  UI as JSX
    return(
      <div>
        <h1>Invalid URL!</h1>
      </div>
    );
  }
}

export default Error;
