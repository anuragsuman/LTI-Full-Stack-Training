import React,{ Component } from "react";

class Home extends Component{
  // method from Component to be overridden
  render(){
    // must return  UI as JSX
    return(
      <div>
        <h1>This is Home Page!</h1>
      </div>
    );
  }
}

export default Home;
