const { createStore } = require("redux");

// initial state 
const initialState = {
    count : 0
}

// reducer function
// responsible to shape up the state object
// must always return the updated state object
// reducer also recieve 2 param
// 1. current state object 
// 2. wrapper object (passed using dispatch)
function reducer(state = initialState, action){
    console.log(state);
    console.log(action);
    switch(action.type){
        case "INCREMENT" : 
        return {
            count : state.count + 1
        };
        case "DECREMENT" :
            return {
                count : state.count -1
            };  
        default : return state;    
    }
}
/*function reducer(){
    // login
    return {
        count : 5
        // more flds
        // f1 : "HEllo",
        // f2 : []
        // default fld
        // dispatch : () => {}
    }
}*/

// create a store
const store = createStore(reducer);

export default store;