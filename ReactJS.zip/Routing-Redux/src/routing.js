import React from 'react';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import Counter from './Counter';
import Error from './Error';
const { Link, BrowserRouter, Route, Switch } = require("react-router-dom");


const routing = (
    <BrowserRouter>
        {/*Menu*/}
        <ul>
            <li><Link to="/">HOME</Link></li>
            <li><Link to="/about">ABOUT US</Link></li>
            <li><Link to="/contact">CONTACT US</Link></li>
            <li><Link to="/counter">COUNTER</Link></li>
        </ul>
        <hr/>
        <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/contact" component={Contact} />
            <Route path="/counter" component={Counter} />
            {/*Fall back*/}
            <Route  component={Error} />
        </Switch>
    </BrowserRouter>
);

export default routing;